/* --- Archivo: script.js --- */
/* ------------------------------------------------------------- */
/* 🚀 Bloque de Datos Centralizado (ZONA ADMIN) 🚀 */
/* ------------------------------------------------------------- */

/* 🏷️ CATEGORÍAS (AÑADE/EDITA AQUÍ) */
const categories = [
  {id: 'all', label: 'Todo'},
  {id: 'Lua', label: 'Archivos .Lua'},
  {id: 'cleos', label: 'Cleos'},
  {id: 'vehiculos', label: 'Skins de vehículos'},
  {id: 'texturas', label: 'Texturas'},
  {id: 'graficos', label: 'Gráficos'},
  {id: 'mapas', label: 'Mapas'},
  {id: 'skins', label: 'Skins de personaje'},
  {id: 'mods', label: 'Mods Anti-Lag'},
  {id: 'Animaciones', label: 'Animaciones'},
  {id: 'hud', label: 'Fonts HUD'},
  {id: 'chat', label: 'Fonts chat'},
  {id: 'timecyc', label: 'Timecyc Anti-Lag'},
  {id: 'Graficos', label: 'Gráficos HD'},
  {id: 'Nubes', label: 'Nubes'},
  {id: 'iconos', label: 'Iconos'},
  {id: 'Base iconos', label: 'Base de icono'},
  {id: 'radardisc', label: 'Radardisc'},
  {id: 'efectos', label: 'Efectos'},
  {id: 'vegetaciones', label: 'Vegetaciones'},
  {id: 'packs', label: 'Packs de Armas'},
  {id: 'workshop', label: 'Workshop'}, 
];

/* 💾 ARCHIVOS (MODS) - Bloque de Datos generado por Apps Script (REEMPLAZAR AL ACTUALIZAR) */
const items = [
  {
    id:1,nombre:"Pack CLEO Básico",categoria:"cleos",descripcion:"Scripts esenciales y menús CLEO. Incluye Srt3 y FPS Counter.",
    img_url:"https://i.imgur.com/fE0NThJ.jpeg",media_url:"https://i.imgur.com/fE0NThJ.jpeg",media_type:"img",link:"https://drive.google.com/uc?export=download&id=1jYe6pMotp4p80GtxOY0e-OBHHuCIjB2S"
  },
  {
    id:2,nombre:"Carros Realistas",categoria:"vehiculos",descripcion:"Pack de vehículos HD optimizados para SAMP. Mejora la experiencia visual.",
    img_url:"https://i.imgur.com/uR1i3X0.jpeg",media_url:"https://i.imgur.com/uR1i3X0.jpeg",media_type:"img",link:"https://www.mediafire.com/file/px7t33gonkukcpt/SA-MP_Mobile_v7.7.2.apk?d=1"
  },
  {
    id:3,nombre:"Mapa Base RCA",categoria:"mapas",descripcion:"Zona personalizada para servidores de rol. Ideal para bases militares.",
    img_url:"https://i.imgur.com/XwY4O8N.jpeg",media_url:"https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=0&controls=1",media_type:"iframe",link:"https://www.mediafire.com/file/aaaaa"
  },
  {
    id:4,nombre:"Texturas HD",categoria:"texturas",descripcion:"Mejora visual sin perder rendimiento. Reemplaza la textura original de las calles.",
    img_url:"https://i.imgur.com/Z4e6i80.jpeg",media_url:"https://i.imgur.com/Z4e6i80.jpeg",media_type:"img",link:"https://www.mediafire.com/file/bbbbb"
  },
  {
    id:5,nombre:"HUD Blanco Minimal",categoria:"hud",descripcion:"HUD minimalista estilo RCA. Fuentes limpias y un diseño que no estorba.",
    img_url:"https://i.imgur.com/W2tWd4C.jpeg",media_url:"https://i.imgur.com/W2tWd4C.jpeg",media_type:"img",link:"https://www.mediafire.com/file/ddddd"
  },
  {
    id:6,nombre:"Skins Hombres Pack",categoria:"skins",descripcion:"Skins masculinos variados. Una colección de alta calidad para personajes.",
    img_url:"https://i.imgur.com/9Gz2LhJ.jpeg",media_url:"https://i.imgur.com/9Gz2LhJ.jpeg",media_type:"img",link:"https://www.mediafire.com/file/eeeee"
  },
  {
    id:7,nombre:"Timecyc & Ant Lag",categoria:"timecyc",descripcion:"Mejora colores, iluminación y rendimiento. Especial para dispositivos de gama baja.",
    img_url:"https://i.imgur.com/E1L3OqM.jpeg",media_url:"https://i.imgur.com/E1L3OqM.jpeg",media_type:"img",link:"https://www.mediafire.com/file/fffff"
  },
  {
    id:8,nombre:"Data Vehículos",categoria:"vehiculos",descripcion:"Archivos .dat para ajuste de velocidad y manejo de coches. Aumenta el realismo.",
    img_url:"https://i.imgur.com/eG1rJ8A.jpeg",media_url:"https://i.imgur.com/eG1rJ8A.jpeg",media_type:"img",link:"https://www.mediafire.com/file/ggggg"
  },
  {
    id:9,nombre:"Animaciones Básicas",categoria:"Animaciones",descripcion:"Animaciones extra para personajes (correr, caminar, estar parado).",
    img_url:"https://i.imgur.com/H1X0c6P.jpeg",media_url:"https://i.imgur.com/H1X0c6P.jpeg",media_type:"img",link:"https://www.mediafire.com/file/hhhhh"
  },
  {
    id:10,nombre:"Armas de Fuego HD",categoria:"packs",descripcion:"Texturas HD para todas las armas del juego. Diseño militar y detallado.",
    img_url:"https://i.imgur.com/G5qB7Lh.jpeg",media_url:"https://i.imgur.com/G5qB7Lh.jpeg",media_type:"img",link:"https://www.mediafire.com/file/jjjjj"
},
{
    id:11,nombre:"CLEO Anti-Lag",categoria:"cleos",descripcion:"CLEO anti-lag listo para funcionar. Mejora el rendimiento.",
    img_url:"https://i.imgur.com/B9O0S52.jpeg",media_url:"https://i.imgur.com/B9O0S52.jpeg",media_type:"img",link:"https://www.mediafire.com/file/kkkkk"
  },
  {
    id:12,nombre:"Nubes realistas",categoria:"Nubes",descripcion:"Nubes para tu gta san andreas.",
    img_url:"https://i.imgur.com/p19u1vB.jpeg",media_url:"https://i.imgur.com/p19u1vB.jpeg",media_type:"img",link:"https://www.mediafire.com/file/kkkkk"
  }
];
/* ------------------------------------------------------------- */
/* 🧠 Lógica del Sitio (NO EDITAR ESTA PARTE) 🧠 */
/* ------------------------------------------------------------- */
let currentCategory = 'all';
let activeZoomCard = null; 
let scrollPosition = 0; 

function makeCard(it){
  const div = document.createElement('div');
  div.className = 'card';
  div.setAttribute('tabindex', '0'); 
  div.setAttribute('data-item-id', it.id); 
  
  div.innerHTML = `
    <div class="thumb" onclick="toggleZoom(this.parentNode, event)" title="Ampliar imagen">
      <img src="${it.img_url}" alt="${escapeHtml(it.nombre)}">
    </div>
    <div class="meta" onclick="openModal(${it.id})" title="Ver detalles y descargar">
      <h4 class="card-title">${it.nombre}</h4>
      <div class="tag">${categories.find(c => c.id === it.categoria)?.label || it.categoria}</div>
    </div>
  `;
  return div;
}

function toggleZoom(card, event) {
  event.stopPropagation(); 
  const zoomOverlay = document.getElementById('zoomOverlay');

  if (card.classList.contains('zoom-active')) {
    closeZoom();
  } else {
    if (activeZoomCard) {
      activeZoomCard.classList.remove('zoom-active');
    }

    scrollPosition = window.pageYOffset;
    document.body.style.top = `-${scrollPosition}px`;
    document.body.classList.add('scroll-lock');
    
    card.classList.add('zoom-active');
    zoomOverlay.classList.add('active');
    activeZoomCard = card;
  }
}

function closeZoom(event) {
    if (activeZoomCard) {
        activeZoomCard.classList.remove('zoom-active');
        document.getElementById('zoomOverlay').classList.remove('active');
        
        document.body.classList.remove('scroll-lock');
        document.body.style.top = ''; 
        window.scrollTo(0, scrollPosition); 
        
        activeZoomCard = null;
    }
}


function render(list){
  const grid = document.getElementById('grid');
  grid.innerHTML='';
  if(!list.length){
    document.getElementById('empty').style.display='block';
    return;
  }
  document.getElementById('empty').style.display='none';
  list.forEach(i=>grid.appendChild(makeCard(i)));
}

function applyFilters(){
  const q = (document.getElementById('search').value||'').toLowerCase().trim();
  let list = items.slice();
  if(currentCategory !== 'all') list = list.filter(x => x.categoria === currentCategory);
  if(q) list = list.filter(x => x.nombre.toLowerCase().includes(q) || x.descripcion.toLowerCase().includes(q));
  render(list);
}

function renderDropdownItems(){
  const menu = document.getElementById('dropdownMenu');
  menu.innerHTML = '';
  categories.forEach(cat => {
    const item = document.createElement('div');
    item.className = 'dropdown-item';
    item.textContent = cat.label;
    item.setAttribute('tabindex', '0'); 
    item.setAttribute('data-cat', cat.id);
    item.onclick = () => { setCategory(cat.id); toggleDropdown(false); };
    menu.appendChild(item);
  });
}

function toggleDropdown(state){
  const menu = document.getElementById('dropdownMenu');
  const btn = document.getElementById('filterBtn');
  const isOpen = state === true || (state === undefined && !menu.classList.contains('open'));
  
  if (isOpen) {
    menu.style.display = 'block';
    setTimeout(() => {
      menu.classList.add('open');
      btn.querySelector('svg').style.transform = 'rotate(180deg)';
    }, 10);
  } else {
    menu.classList.remove('open');
    btn.querySelector('svg').style.transform = 'rotate(0deg)';
    setTimeout(() => {
      menu.style.display = 'none';
    }, 300);
  }
}

function setCategory(cat){
  currentCategory = cat;
  const label = categories.find(c => c.id === cat)?.label || 'Todo';
  document.getElementById('currentCatLabel').textContent = `(${label})`; 
  document.querySelectorAll('.dropdown-item').forEach(c => c.classList.remove('active'));
  const activeItem = document.querySelector(`.dropdown-item[data-cat="${cat}"]`);
  if(activeItem) activeItem.classList.add('active');
  applyFilters();
}

function openModal(itemId){
  closeZoom();

  const item = items.find(i => i.id === itemId);
  if (!item) return;

  document.getElementById('detailName').textContent = item.nombre;
  document.getElementById('detailCategory').textContent = categories.find(c => c.id === item.categoria)?.label || item.categoria;
  document.getElementById('detailDescription').textContent = item.descripcion;
  document.getElementById('detailDownload').href = item.link;
  document.getElementById('detailIcon').innerHTML = `<img src="${item.img_url}" alt="${item.nombre}">`;

  const recommendations = items
    .filter(i => i.categoria === item.categoria && i.id !== item.id)
    .slice(0, 4);
    
  const recGrid = document.getElementById('recommendationsGrid');
  recGrid.innerHTML = '';
  if (recommendations.length > 0) {
    recommendations.forEach(rec => {
      const recCard = document.createElement('div');
      recCard.className = 'rec-card';
      recCard.setAttribute('tabindex', '0'); 
      recCard.setAttribute('onclick', `openModal(${rec.id}); event.stopPropagation();`);
      recCard.innerHTML = `
        <div class="rec-thumb"><img src="${rec.img_url}" alt="${rec.nombre}"></div>
        <div class="rec-meta"><h5>${rec.nombre}</h5></div>
      `;
      recGrid.appendChild(recCard);
    });
  } else {
    recGrid.innerHTML = '<p style="font-size:14px; color:var(--muted); margin-top:10px;">No hay otros archivos similares en esta categoría.</p>';
  }

  const modal = document.getElementById('detailModal');
  const body = document.body;
  
  scrollPosition = window.pageYOffset;
  document.body.style.top = `-${scrollPosition}px`;
  body.classList.add('scroll-lock'); 
  
  modal.style.display = 'grid';
  
  setTimeout(() => {
      modal.classList.add('open');
  }, 10);
}

function closeModal(event){
  if(event && event.target.id !== 'detailModal' && !event.target.classList.contains('close-btn')) {
    return;
  }
  
  const modal = document.getElementById('detailModal');
  
  modal.classList.remove('open');
  
  setTimeout(() => {
      modal.style.display = 'none';
      
      document.body.classList.remove('scroll-lock');
      document.body.style.top = ''; 
      window.scrollTo(0, scrollPosition); 
  }, 400); 
}

// ESTA LÍNEA ES CRÍTICA: Se asegura de que los archivos se carguen al iniciar.
window.addEventListener('load', () => {
  renderDropdownItems();
  setCategory('all');
});

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c=> ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
